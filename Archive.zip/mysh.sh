#!/bin/sh
cd /src/ && supervisord -c supervisord.conf
